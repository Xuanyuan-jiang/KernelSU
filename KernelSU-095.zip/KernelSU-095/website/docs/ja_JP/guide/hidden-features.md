# 隠し機能

## .ksurc

デフォルトでは `/system/bin/sh` は `/system/etc/mkshrc` を読み込みます。

`/data/adb/ksu/.ksurc` ファイルを作成することで、カスタマイズした rc ファイルを su に読み込ませられます。